require 'test_helper'

class ArticulosHelperTest < ActionView::TestCase
end
