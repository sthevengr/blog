require 'test_helper'

class BienvenidoHelperTest < ActionView::TestCase
end
