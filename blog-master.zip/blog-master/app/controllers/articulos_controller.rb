class ArticulosController < ApplicationController
end
