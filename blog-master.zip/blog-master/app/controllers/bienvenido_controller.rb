class BienvenidoController < ApplicationController
  def new 
   
  end
end
